extends Node
## Supabase REST/Auth client. Only the PUBLIC anon key lives in the app (safe by design;
## Row Level Security + server functions protect the data). No admin secrets here.

var url := ""
var anon_key := ""
var access_token := ""
var refresh_token := ""
var user_id := ""
var email := ""

func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("res://config/backend.cfg") == OK:
		url = str(cfg.get_value("supabase", "url", "")).rstrip("/")
		anon_key = str(cfg.get_value("supabase", "anon_key", ""))

func is_configured() -> bool:
	return url.begins_with("https://") and anon_key != "" and not anon_key.begins_with("YOUR_")

func logged_in() -> bool:
	return access_token != "" and user_id != ""

func request(method: int, path: String, body = null, use_user_token := true) -> Dictionary:
	var http := HTTPRequest.new()
	http.timeout = 15.0
	add_child(http)
	var token := access_token if (use_user_token and access_token != "") else anon_key
	var headers := PackedStringArray(["apikey: " + anon_key, "Authorization: Bearer " + token, "Content-Type: application/json"])
	var payload := "" if body == null else JSON.stringify(body)
	var err := http.request(url + path, headers, method, payload)
	if err != OK:
		http.queue_free()
		return {"ok": false, "code": 0, "data": null, "error": "Network error"}
	var res: Array = await http.request_completed
	http.queue_free()
	var code: int = res[1]
	var text: String = (res[3] as PackedByteArray).get_string_from_utf8()
	var parsed = JSON.parse_string(text) if text != "" else null
	var ok: bool = res[0] == HTTPRequest.RESULT_SUCCESS and code >= 200 and code < 300
	var msg := ""
	if not ok:
		msg = "Network error" if code == 0 else "Request failed"
		if parsed is Dictionary:
			for k in ["msg", "error_description", "message", "error"]:
				if parsed.has(k):
					msg = str(parsed[k])
					break
	return {"ok": ok, "code": code, "data": parsed, "error": msg}

func get_rest(path: String) -> Dictionary:
	return await request(HTTPClient.METHOD_GET, path)

func rpc(fn: String, args: Dictionary = {}) -> Dictionary:
	return await request(HTTPClient.METHOD_POST, "/rest/v1/rpc/" + fn, args)

func _apply_session(d: Dictionary) -> void:
	access_token = str(d.get("access_token", ""))
	refresh_token = str(d.get("refresh_token", ""))
	var u = d.get("user", {})
	if u is Dictionary:
		user_id = str(u.get("id", ""))
		email = str(u.get("email", ""))
	_store_session()

func sign_up(mail: String, password: String, username: String) -> Dictionary:
	var r := await request(HTTPClient.METHOD_POST, "/auth/v1/signup",
		{"email": mail, "password": password, "data": {"username": username}}, false)
	if r.ok and r.data is Dictionary and r.data.has("access_token"):
		_apply_session(r.data)
	return r

func sign_in(mail: String, password: String) -> Dictionary:
	var r := await request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=password",
		{"email": mail, "password": password}, false)
	if r.ok and r.data is Dictionary:
		_apply_session(r.data)
	return r

func recover(mail: String) -> Dictionary:
	return await request(HTTPClient.METHOD_POST, "/auth/v1/recover", {"email": mail}, false)

func restore_session() -> bool:
	var cfg := ConfigFile.new()
	if cfg.load_encrypted_pass("user://session.cfg", OS.get_unique_id()) != OK:
		return false
	refresh_token = str(cfg.get_value("s", "refresh", ""))
	if refresh_token == "":
		return false
	var r := await request(HTTPClient.METHOD_POST, "/auth/v1/token?grant_type=refresh_token",
		{"refresh_token": refresh_token}, false)
	if r.ok and r.data is Dictionary:
		_apply_session(r.data)
		return true
	sign_out_local()
	return false

func sign_out() -> void:
	if logged_in():
		await request(HTTPClient.METHOD_POST, "/auth/v1/logout")
	sign_out_local()

func sign_out_local() -> void:
	access_token = ""; refresh_token = ""; user_id = ""; email = ""
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://session.cfg"))

func _store_session() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("s", "refresh", refresh_token)
	cfg.save_encrypted_pass("user://session.cfg", OS.get_unique_id())
