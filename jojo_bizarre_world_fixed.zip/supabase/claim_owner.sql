-- Run ONCE in Supabase SQL Editor BEFORE you register "Thoxq1" in the game.
-- Replace the email with YOUR real email (the one you'll register with).
insert into public.owner_claim (email) values ('PUT_YOUR_EMAIL_HERE');
