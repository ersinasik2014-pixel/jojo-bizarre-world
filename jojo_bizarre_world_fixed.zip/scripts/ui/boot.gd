extends Control

func _ready() -> void:
	UIKit.background(self)
	var box := UIKit.column(self)
	var title := UIKit.label("JoJo: Bizarre World", 60, Color(1, 0.85, 0.3))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	var status := UIKit.label("Loading...", 28)
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(status)
	await get_tree().create_timer(0.6).timeout
	if not Backend.is_configured():
		status.text = "Backend not configured yet. Follow SETUP.md (Supabase URL + key)."
		return
	status.text = "Signing in..."
	if await Backend.restore_session():
		var err := await GameState.enter_game()
		if err == "":
			get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
			return
	get_tree().change_scene_to_file("res://scenes/login.tscn")
