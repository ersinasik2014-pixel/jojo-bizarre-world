class_name VirtualJoystick
extends Control
## Multi-touch joystick (works together with TouchButtons).
var vec := Vector2.ZERO
var index := -1
var radius := 90.0

func _init() -> void:
	size = Vector2(260, 260)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and index == -1 and get_global_rect().has_point(event.position):
			index = event.index
			_update(event.position)
		elif not event.pressed and event.index == index:
			index = -1
			vec = Vector2.ZERO
			queue_redraw()
	elif event is InputEventScreenDrag and event.index == index:
		_update(event.position)

func _update(p: Vector2) -> void:
	vec = ((p - (global_position + size / 2.0)) / radius).limit_length(1.0)
	queue_redraw()

func _draw() -> void:
	var c := size / 2.0
	draw_circle(c, radius + 20, Color(0, 0, 0, 0.35))
	draw_arc(c, radius + 20, 0, TAU, 48, Color(1, 1, 1, 0.8), 3.0)
	draw_circle(c + vec * radius, 38, Color(1, 1, 1, 0.55))
