extends Node3D
## Playable 3D prototype world: movement, camera, day/night, combat, Stand Arrow/Rokakaka loop.
## Visuals are PLACEHOLDER primitives until real licensed/original 3D assets are added.

const SPAWN := Vector3(0, 1.5, 0)
const MAX_ENEMIES := 8

var player: CharacterBody3D
var cam_pivot: Node3D
var sun: DirectionalLight3D
var env: Environment
var joy: VirtualJoystick
var buttons := {}
var stand_node: MeshInstance3D
var stand_mat: StandardMaterial3D
var stand_out := false
var hp := 100.0
var yaw := 0.0
var day_time := 0.2
var attack_cd := 0.0
var dash_t := 0.0
var toast_t := 0.0
var hud_t := 0.0
var pos_t := 0.0
var spawn_t := 0.0
var lbl_info: Label
var lbl_toast: Label
var bar_hp: ProgressBar
var pause_panel: Control
var pickups: Array = []
var building_rects: Array = []
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	GameState.check_daily()
	_build_world()
	_build_player()
	_build_hud()
	_spawn_daily_pickups()
	for i in MAX_ENEMIES:
		_spawn_enemy()
	_apply_graphics()
	_refresh_stand_visual()

# ---------------------------------------------------------------- world
func _add_box(size: Vector3, pos: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	mi.material_override = m
	body.add_child(mi)
	add_child(body)

func _build_world() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	add_child(sun)
	_add_box(Vector3(400, 1, 400), Vector3(0, -0.5, 0), Color(0.36, 0.46, 0.36))
	var city := RandomNumberGenerator.new()
	city.seed = 1234   # fixed layout: placeholder "Morioh-style" town blocks
	for i in 70:
		var p := Vector3(city.randf_range(-150, 150), 0, city.randf_range(-150, 150))
		if Vector2(p.x, p.z).length() < 14.0:
			continue
		var s := Vector3(city.randf_range(6, 14), city.randf_range(6, 28), city.randf_range(6, 14))
		var col := Color.from_hsv(city.randf_range(0.0, 1.0), 0.25, city.randf_range(0.7, 0.95))
		_add_box(s, Vector3(p.x, s.y / 2.0, p.z), col)
		building_rects.append(Rect2(p.x - s.x / 2 - 2, p.z - s.z / 2 - 2, s.x + 4, s.z + 4))

func _free_spot(min_dist: float, max_dist: float) -> Vector3:
	for attempt in 40:
		var a := rng.randf() * TAU
		var d := rng.randf_range(min_dist, max_dist)
		var p := Vector3(cos(a) * d, 0.0, sin(a) * d)
		var blocked := false
		for r in building_rects:
			if r.has_point(Vector2(p.x, p.z)):
				blocked = true
				break
		if not blocked:
			return p
	return Vector3(20, 0, 20)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.add_to_group("player")
	var cs := CollisionShape3D.new()
	cs.shape = CapsuleShape3D.new()
	player.add_child(cs)
	var mi := MeshInstance3D.new()
	mi.mesh = CapsuleMesh.new()
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 0.35, 0.8)
	mi.material_override = m
	player.add_child(mi)
	stand_node = MeshInstance3D.new()
	var sm := CapsuleMesh.new()
	sm.radius = 0.45
	sm.height = 2.1
	stand_node.mesh = sm
	stand_mat = StandardMaterial3D.new()
	stand_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	stand_mat.emission_enabled = true
	stand_node.material_override = stand_mat
	stand_node.position = Vector3(0.9, 0.2, 0.8)
	stand_node.visible = false
	player.add_child(stand_node)
	add_child(player)
	var pos = GameState.data.get("position", [0.0, 1.5, 0.0])
	player.position = Vector3(float(pos[0]), maxf(float(pos[1]), 1.5), float(pos[2]))
	cam_pivot = Node3D.new()
	add_child(cam_pivot)
	var cam := Camera3D.new()
	cam.position = Vector3(0, 2.2, 6.5)
	cam.rotation_degrees.x = -12
	cam_pivot.add_child(cam)
	cam.current = true

func _refresh_stand_visual() -> void:
	var id: String = GameState.data["current_stand"]
	stand_node.visible = stand_out and id != ""
	if id != "":
		var col := Color.from_hsv(float(absi(hash(id)) % 360) / 360.0, 0.65, 1.0, 0.55)
		stand_mat.albedo_color = col
		stand_mat.emission = Color(col.r, col.g, col.b)

func _apply_graphics() -> void:
	var g: String = GameState.data["settings"]["graphics"]
	sun.shadow_enabled = g != "low"
	get_viewport().msaa_3d = Viewport.MSAA_2X if g == "high" else Viewport.MSAA_DISABLED
	env.glow_enabled = g == "high"

# ---------------------------------------------------------------- HUD
func _btn(key: String, text: String, pos: Vector2, sz: float) -> TouchButton:
	var b := TouchButton.new(text, Vector2(sz, sz))
	b.position = pos
	$HUD/Root.add_child(b)
	buttons[key] = b
	return b

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	var root := Control.new()
	root.name = "Root"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	var vs := get_viewport().get_visible_rect().size
	joy = VirtualJoystick.new()
	joy.position = Vector2(50, vs.y - 310)
	root.add_child(joy)
	_btn("attack", "Attack", Vector2(vs.x - 190, vs.y - 200), 150).pressed.connect(_attack)
	_btn("jump", "Jump", Vector2(vs.x - 330, vs.y - 130), 110).pressed.connect(_jump)
	_btn("dash", "Dash", Vector2(vs.x - 190, vs.y - 330), 110).pressed.connect(func(): dash_t = 0.2)
	_btn("block", "Block", Vector2(vs.x - 330, vs.y - 260), 110)
	_btn("stand", "Stand", Vector2(vs.x - 470, vs.y - 170), 110).pressed.connect(_toggle_stand)
	_btn("menu", "Menu", Vector2(vs.x - 130, 20), 100).pressed.connect(_toggle_pause)
	_btn("arrow", "Arrow", Vector2(vs.x - 250, 20), 100).pressed.connect(_use_arrow)
	_btn("fruit", "Fruit", Vector2(vs.x - 370, 20), 100).pressed.connect(_eat_rokakaka)
	bar_hp = ProgressBar.new()
	bar_hp.max_value = 100
	bar_hp.show_percentage = false
	bar_hp.position = Vector2(20, 20)
	bar_hp.custom_minimum_size = Vector2(340, 28)
	bar_hp.size = Vector2(340, 28)
	root.add_child(bar_hp)
	lbl_info = UIKit.label("", 22)
	lbl_info.position = Vector2(20, 56)
	lbl_info.custom_minimum_size = Vector2(560, 0)
	root.add_child(lbl_info)
	lbl_toast = UIKit.label("", 30, Color(1, 0.9, 0.4))
	lbl_toast.position = Vector2(vs.x / 2 - 300, vs.y * 0.18)
	lbl_toast.custom_minimum_size = Vector2(600, 0)
	lbl_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(lbl_toast)
	pause_panel = ColorRect.new()
	pause_panel.color = Color(0, 0, 0, 0.75)
	pause_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_panel.visible = false
	var pb := UIKit.column(pause_panel, 500)
	pb.add_child(UIKit.button("Resume", _toggle_pause))
	pb.add_child(UIKit.button("Save & Exit to Menu", _exit_to_menu))
	root.add_child(pause_panel)

func _toast(text: String) -> void:
	lbl_toast.text = text
	toast_t = 3.5

func _toggle_pause() -> void:
	pause_panel.visible = not pause_panel.visible

func _exit_to_menu() -> void:
	await SaveManager.save_now("exit")
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")

func _update_hud() -> void:
	var d: Dictionary = GameState.data
	var q: Dictionary = d["quests"].get("daily_defeat_3", {"progress": 0, "done": false})
	var qtxt := "DONE" if q["done"] else "%d/3" % int(q["progress"])
	lbl_info.text = "%s  Lv %d  XP %d/%d  Coins %d\nStand: %s   Arrows %d   Rokakaka %d\nDaily quest - defeat 3 enemies: %s" % [
		GameState.username, d["level"], d["xp"], GameState.xp_needed(int(d["level"])), d["coins"],
		Db.stand_name(d["current_stand"]), GameState.count("stand_arrow"), GameState.count("rokakaka"), qtxt]
	bar_hp.value = hp

# ---------------------------------------------------------------- input / loop
func _input(event: InputEvent) -> void:
	if event is InputEventScreenDrag and not pause_panel.visible:
		var vs := get_viewport().get_visible_rect().size
		if event.position.x > vs.x * 0.45 and event.index != joy.index:
			for b in buttons.values():
				if b.touch_index == event.index:
					return
			yaw -= event.relative.x * 0.006

func _jump() -> void:
	if player.is_on_floor():
		player.velocity.y = 9.0

func _physics_process(delta: float) -> void:
	var v := joy.vec
	var dir := Vector3(v.x, 0, v.y).rotated(Vector3.UP, yaw)
	var speed := 7.0
	if dash_t > 0.0:
		dash_t -= delta
		speed = 20.0
		if dir.length() < 0.1:
			dir = -player.global_transform.basis.z
	if buttons["block"].held:
		speed *= 0.4
	player.velocity.x = dir.x * speed
	player.velocity.z = dir.z * speed
	if not player.is_on_floor():
		player.velocity.y -= 24.0 * delta
	player.move_and_slide()
	if dir.length() > 0.1:
		player.rotation.y = lerp_angle(player.rotation.y, atan2(-dir.x, -dir.z), 0.2)
	cam_pivot.global_position = player.global_position + Vector3(0, 1.0, 0)
	cam_pivot.rotation.y = yaw
	if player.position.y < -20.0:
		player.position = SPAWN

func _process(delta: float) -> void:
	attack_cd -= delta
	day_time = fposmod(day_time + delta / 600.0, 1.0)   # 10-minute day/night cycle
	var angle := day_time * TAU
	var light := clampf(sin(angle), 0.0, 1.0)
	sun.rotation.x = -angle
	sun.light_energy = light * 1.2
	env.background_energy_multiplier = lerpf(0.08, 1.0, clampf(sin(angle) + 0.25, 0.0, 1.0))
	env.ambient_light_energy = lerpf(0.25, 1.0, light)
	for p in pickups:
		if is_instance_valid(p):
			p.rotate_y(delta * 1.5)
	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0:
			lbl_toast.text = ""
	hud_t += delta
	if hud_t > 0.25:
		hud_t = 0.0
		_update_hud()
	pos_t += delta
	if pos_t > 1.0:
		pos_t = 0.0
		GameState.data["position"] = [player.position.x, player.position.y, player.position.z]
	spawn_t += delta
	if spawn_t > 10.0:
		spawn_t = 0.0
		if get_tree().get_nodes_in_group("enemy").size() < MAX_ENEMIES:
			_spawn_enemy()

# ---------------------------------------------------------------- combat
func _toggle_stand() -> void:
	if GameState.data["current_stand"] == "":
		_toast("You have no Stand. Find a Stand Arrow!")
		return
	stand_out = not stand_out
	_refresh_stand_visual()

func _attack() -> void:
	if attack_cd > 0.0:
		return
	attack_cd = 0.4
	var has_stand := stand_out and GameState.data["current_stand"] != ""
	var dmg := 10.0 + float(GameState.data["level"]) * 1.5 + (18.0 if has_stand else 0.0)
	var reach := 3.6 if has_stand else 2.6
	var fwd := -player.global_transform.basis.z
	for e in get_tree().get_nodes_in_group("enemy"):
		var to: Vector3 = e.global_position - player.global_position
		if to.length() <= reach and fwd.dot(to.normalized()) > 0.2:
			e.hit(dmg, player.global_position)
	if has_stand:
		var tw := create_tween()
		tw.tween_property(stand_node, "position:z", -1.2, 0.08)
		tw.tween_property(stand_node, "position:z", 0.8, 0.15)

func _spawn_enemy() -> void:
	var e = CharacterBody3D.new()
	e.set_script(load("res://scripts/enemy.gd"))
	e.set("player", player)
	e.connect("died", _on_enemy_died)
	e.connect("hit_player", _on_player_hit)
	add_child(e)
	var p := _free_spot(15.0, 90.0)
	e.global_position = Vector3(p.x + player.position.x * 0.0, 1.5, p.z)

func _on_player_hit(dmg: float) -> void:
	hp -= dmg * (0.4 if buttons["block"].held else 1.0)
	if hp <= 0.0:
		hp = 100.0
		player.position = SPAWN
		_toast("You were defeated. Respawned.")

func _on_enemy_died(_e) -> void:
	GameState.add_xp(20)
	GameState.add_coins(15)
	var quests: Dictionary = GameState.data["quests"]
	var q: Dictionary = quests.get("daily_defeat_3", {"progress": 0, "done": false})
	if not q["done"]:
		q["progress"] = int(q["progress"]) + 1
		if q["progress"] >= 3:
			q["done"] = true
			GameState.add_coins(150)
			GameState.add_xp(50)
			_toast("Quest complete! +150 coins, +50 XP")
			SaveManager.save_now("quest")
		quests["daily_defeat_3"] = q

# ---------------------------------------------------------------- Arrow / Rokakaka loop
func _use_arrow() -> void:
	if GameState.count("stand_arrow") <= 0:
		_toast("You have no Stand Arrow.")
		return
	if GameState.data["current_stand"] != "":
		_toast("You already have a Stand. Eat a Rokakaka first!")
		return
	GameState.remove_item("stand_arrow", 1)
	var s := Db.random_stand()
	GameState.grant_stand(s["id"])
	stand_out = true
	_refresh_stand_visual()
	_toast("You obtained: %s [%s]" % [s["name"], s["rarity"]])
	SaveManager.save_now("stand")

func _eat_rokakaka() -> void:
	if GameState.count("rokakaka") <= 0:
		_toast("You have no Rokakaka.")
		return
	if GameState.data["current_stand"] == "":
		_toast("You have no Stand to reset.")
		return
	GameState.remove_item("rokakaka", 1)
	GameState.data["current_stand"] = ""
	stand_out = false
	_refresh_stand_visual()
	_toast("Your Stand faded away... use a Stand Arrow.")
	SaveManager.save_now("rokakaka")

func _spawn_daily_pickups() -> void:
	# Fixed per-day layout; collected ones stay gone until the next day.
	var day := RandomNumberGenerator.new()
	day.seed = hash(GameState.data["daily_date"])
	var specs := [["stand_arrow", 2], ["rokakaka", 2]]
	var idx := 0
	for spec in specs:
		for i in spec[1]:
			var a := day.randf() * TAU
			var d := day.randf_range(25.0, 140.0)
			_make_pickup("p%d" % idx, spec[0], Vector3(cos(a) * d, 1.2, sin(a) * d))
			idx += 1
	_make_pickup("secret", "stand_arrow", Vector3(185, 1.2, -185))   # hidden corner of the map

func _make_pickup(id: String, kind: String, pos: Vector3) -> void:
	if GameState.data["collected"].has(id):
		return
	var area := Area3D.new()
	var cs := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = 1.8
	cs.shape = sp
	area.add_child(cs)
	var mi := MeshInstance3D.new()
	var m := StandardMaterial3D.new()
	m.emission_enabled = true
	if kind == "stand_arrow":
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.0
		cyl.bottom_radius = 0.25
		cyl.height = 1.6
		mi.mesh = cyl
		m.albedo_color = Color(1.0, 0.85, 0.2)
		m.emission = Color(1.0, 0.8, 0.1)
	else:
		mi.mesh = SphereMesh.new()
		m.albedo_color = Color(0.6, 0.1, 0.5)
		m.emission = Color(0.8, 0.1, 0.6)
	mi.material_override = m
	area.add_child(mi)
	var light := OmniLight3D.new()
	light.light_color = m.emission
	light.omni_range = 8.0
	area.add_child(light)
	area.position = pos
	add_child(area)
	pickups.append(area)
	area.body_entered.connect(func(b):
		if b == player:
			GameState.add_item(kind, 1)
			GameState.data["collected"].append(id)
			_toast("Found: %s" % ("Stand Arrow" if kind == "stand_arrow" else "Rokakaka Fruit"))
			area.queue_free()
			SaveManager.save_now("collect"))
