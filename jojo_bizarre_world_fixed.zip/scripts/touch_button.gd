class_name TouchButton
extends Control
signal pressed
var label_text := ""
var touch_index := -1
var held := false

func _init(t := "", sz := Vector2(120, 120)) -> void:
	label_text = t
	size = sz
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and touch_index == -1 and get_global_rect().has_point(event.position):
			touch_index = event.index
			held = true
			pressed.emit()
			queue_redraw()
		elif not event.pressed and event.index == touch_index:
			touch_index = -1
			held = false
			queue_redraw()

func _draw() -> void:
	var c := size / 2.0
	draw_circle(c, size.x / 2.0, Color(1, 1, 1, 0.5) if held else Color(0, 0, 0, 0.45))
	draw_arc(c, size.x / 2.0 - 2, 0, TAU, 48, Color.WHITE, 3.0)
	var f := ThemeDB.fallback_font
	var ts := f.get_string_size(label_text, HORIZONTAL_ALIGNMENT_CENTER, -1, 22)
	draw_string(f, Vector2(c.x - ts.x / 2.0, c.y + 8), label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 22)
