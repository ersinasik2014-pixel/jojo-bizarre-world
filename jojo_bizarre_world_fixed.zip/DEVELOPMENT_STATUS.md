# Development Status (honest)
UNTESTED: this code was written without Godot available, so it has never been run. Expect first-build errors; send me the Actions log and I'll fix them.

## Written
- Supabase schema: profiles, unique usernames, RLS, server-side save validation, backups (last 10), ban/announce/reset RPCs
- OWNER lock: "Thoxq1" reservable only via pre-registered email (claim_owner.sql); owner needs confirmed email; no client can grant roles
- Godot 4.3 project: login / register / forgot password (login uses EMAIL, username is public name), session restore, logout
- Autosave: every 30s, on pause/focus-out/quit/logout, after Arrow, Rokakaka, pickup, quest; local crash backup; newest-wins merge
- 92 Stands (Parts 3-9 starter list, `verified:false` - names need cross-check; Part 1-2 have no Stands; list is NOT complete)
- Stand Arrow (random base Stand, blocked if you have one) and Rokakaka (clears current Stand) with daily hidden pickups
- Placeholder 3D town, day/night, enemies, light attack, Stand attack, dash, block, jump, multi-touch joystick/buttons, one daily quest
- Owner panel: coins, XP, level, unlock all Stands, equip Stand, item search/spawn/remove, ban/unban, view/reset player, announcements
- GitHub Actions: APK; AAB when release keystore secrets exist

## NOT done
- Per-Stand unique models/animations/attacks/sounds (all Stands share a placeholder); evolutions/Requiems are data only
- Real maps (Morioh, Cairo, Naples...), bosses, characters/transformations, shop, achievements, more quests
- Multiplayer, rankings; owner teleport/spawn-enemy/event/economy tools
- Rewarded ads + ad-free purchase (needs AdMob/Play Billing plugins); audio; custom button layout; icon is a placeholder
- Server-side gameplay validation is limited to caps (level<=100, coins<=5M for non-owners); full anti-cheat needs server-authoritative logic
- Licensing: JoJo IP is not licensed; Google Play may reject it
