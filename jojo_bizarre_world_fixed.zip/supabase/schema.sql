-- JoJo: Bizarre World backend. Paste into Supabase > SQL Editor > Run.
-- Passwords are handled and hashed (bcrypt) by Supabase Auth. Nothing here stores passwords.

create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  username text not null check (username ~ '^[A-Za-z0-9_]{3,20}$'),
  banned boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_username_ci on public.profiles (lower(username));

create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users on delete cascade,
  role text not null check (role in ('owner'))
);
create table if not exists public.owner_claim (email text primary key);
create table if not exists public.player_saves (
  user_id uuid primary key references auth.users on delete cascade,
  data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.player_save_backups (
  id bigserial primary key, user_id uuid not null, data jsonb not null,
  created_at timestamptz not null default now());
create table if not exists public.announcements (
  id bigserial primary key, message text not null, created_at timestamptz not null default now());

alter table public.profiles enable row level security;
alter table public.admin_roles enable row level security;
alter table public.owner_claim enable row level security;
alter table public.player_saves enable row level security;
alter table public.player_save_backups enable row level security;
alter table public.announcements enable row level security;

-- Clients may only READ: profiles (public names) and announcements. Everything else is closed;
-- all writes go through the security-definer functions below.
drop policy if exists "profiles readable" on public.profiles;
create policy "profiles readable" on public.profiles for select to authenticated using (true);
drop policy if exists "announcements readable" on public.announcements;
create policy "announcements readable" on public.announcements for select to authenticated using (true);

-- Registration: validates username, reserves "Thoxq1" for the pre-registered owner email only.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare uname text := new.raw_user_meta_data->>'username'; claimed boolean := false;
begin
  if uname is null or uname !~ '^[A-Za-z0-9_]{3,20}$' then raise exception 'Invalid username'; end if;
  if lower(uname) = 'thoxq1' then
    if exists (select 1 from owner_claim where lower(email) = lower(new.email)) then claimed := true;
    else raise exception 'This username is reserved'; end if;
  end if;
  insert into profiles (id, username) values (new.id, uname);
  if claimed then
    insert into admin_roles (user_id, role) values (new.id, 'owner');
    delete from owner_claim where lower(email) = lower(new.email);
  end if;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Owner only counts once the email is CONFIRMED (keep "Confirm email" ON in Supabase Auth settings).
create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admin_roles r join auth.users u on u.id = r.user_id
                 where r.user_id = auth.uid() and r.role = 'owner' and u.email_confirmed_at is not null);
$$;

create or replace function public.save_game(p_data jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); lvl int; coins bigint; own boolean := public.is_owner();
begin
  if uid is null then raise exception 'Not authenticated'; end if;
  if exists (select 1 from profiles where id = uid and banned) then raise exception 'Banned'; end if;
  if jsonb_typeof(p_data) <> 'object' or length(p_data::text) > 262144 then raise exception 'Invalid save'; end if;
  lvl := coalesce(((p_data->>'level')::numeric)::int, 1);
  coins := coalesce(((p_data->>'coins')::numeric)::bigint, 0);
  if lvl < 1 or coins < 0 then raise exception 'Invalid values'; end if;
  if not own and (lvl > 100 or coins > 5000000) then raise exception 'Value out of range'; end if;
  -- backup the previous save at most every 10 minutes, keep the newest 10
  if not exists (select 1 from player_save_backups where user_id = uid and created_at > now() - interval '10 minutes') then
    insert into player_save_backups (user_id, data) select user_id, data from player_saves where user_id = uid;
    delete from player_save_backups where user_id = uid and id not in
      (select id from player_save_backups where user_id = uid order by id desc limit 10);
  end if;
  insert into player_saves (user_id, data, updated_at) values (uid, p_data, now())
    on conflict (user_id) do update set data = excluded.data, updated_at = now();
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.load_game() returns jsonb
language plpgsql security definer set search_path = public as $$
declare d jsonb;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select data into d from player_saves where user_id = auth.uid();
  if d is null then
    select data into d from player_save_backups where user_id = auth.uid() order by id desc limit 1;
  end if;
  return d;
end $$;

create or replace function public.get_my_role() returns text
language sql stable security definer set search_path = public as $$
  select case when public.is_owner() then 'owner' else 'player' end;
$$;

create or replace function public.latest_announcements() returns setof public.announcements
language sql stable security definer set search_path = public as $$
  select * from announcements order by id desc limit 3;
$$;

create or replace function public.admin_set_banned(p_username text, p_banned boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'Forbidden'; end if;
  update profiles set banned = p_banned where lower(username) = lower(p_username)
    and id not in (select user_id from admin_roles);
end $$;

create or replace function public.admin_announce(p_message text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'Forbidden'; end if;
  if length(p_message) < 1 or length(p_message) > 300 then raise exception 'Bad length'; end if;
  insert into announcements (message) values (p_message);
end $$;

create or replace function public.admin_get_player(p_username text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'Forbidden'; end if;
  return (select jsonb_build_object('profile', to_jsonb(p), 'save', s.data)
          from profiles p left join player_saves s on s.user_id = p.id
          where lower(p.username) = lower(p_username));
end $$;

create or replace function public.admin_reset_player(p_username text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'Forbidden'; end if;
  delete from player_saves where user_id = (select id from profiles where lower(username) = lower(p_username))
    and user_id not in (select user_id from admin_roles);
end $$;

-- Lock function access: signed-in players only (never anonymous).
do $$ declare f text; begin
  foreach f in array array['is_owner()','save_game(jsonb)','load_game()','get_my_role()','latest_announcements()',
    'admin_set_banned(text,boolean)','admin_announce(text)','admin_get_player(text)','admin_reset_player(text)']
  loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;
