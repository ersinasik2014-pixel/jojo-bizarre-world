extends Node
const RARITY_WEIGHT := {"common": 50, "uncommon": 28, "rare": 14, "epic": 6, "legendary": 2}
var stands: Array = []
var items: Array = []
var stand_by_id := {}

func _ready() -> void:
	stands = _load("res://data/stands.json")
	items = _load("res://data/items.json")
	for s in stands:
		stand_by_id[s["id"]] = s

func _load(path: String) -> Array:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	return parsed if parsed is Array else []

func stand_name(id: String) -> String:
	return str(stand_by_id[id]["name"]) if stand_by_id.has(id) else "None"

func search_items(q: String) -> Array:
	q = q.to_lower()
	return items.filter(func(i): return q == "" or str(i["name"]).to_lower().contains(q) or str(i["id"]).contains(q))

func random_stand() -> Dictionary:
	# Arrows only give base forms; evolutions/requiems are earned separately.
	var pool: Array = stands.filter(func(s): return s["evolves_from"] == "")
	var total := 0
	for s in pool: total += RARITY_WEIGHT[s["rarity"]]
	var roll := randi() % total
	for s in pool:
		roll -= RARITY_WEIGHT[s["rarity"]]
		if roll < 0:
			return s
	return pool[0]
