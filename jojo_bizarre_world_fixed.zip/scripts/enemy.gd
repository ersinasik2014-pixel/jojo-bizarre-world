extends CharacterBody3D
signal died(enemy)
signal hit_player(dmg)
var hp := 40.0
var player: Node3D
var cd := 0.0

func _ready() -> void:
	add_to_group("enemy")
	var cs := CollisionShape3D.new()
	cs.shape = CapsuleShape3D.new()
	add_child(cs)
	var mi := MeshInstance3D.new()
	mi.mesh = CapsuleMesh.new()
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.6, 0.1, 0.15)
	mi.material_override = m
	add_child(mi)

func hit(dmg: float, from: Vector3) -> void:
	hp -= dmg
	var push := (global_position - from)
	push.y = 0
	velocity += push.normalized() * 7.0
	if hp <= 0:
		died.emit(self)
		queue_free()

func _physics_process(delta: float) -> void:
	if player == null:
		return
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	var to := player.global_position - global_position
	to.y = 0
	var d := to.length()
	var target := Vector3.ZERO
	if d < 16.0 and d > 1.5:
		target = to.normalized() * 3.5
	velocity.x = lerpf(velocity.x, target.x, 0.2)
	velocity.z = lerpf(velocity.z, target.z, 0.2)
	move_and_slide()
	cd -= delta
	if d <= 1.9 and cd <= 0.0:
		cd = 1.2
		hit_player.emit(8.0)
