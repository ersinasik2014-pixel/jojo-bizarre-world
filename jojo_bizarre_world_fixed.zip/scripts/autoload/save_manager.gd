extends Node
signal save_status(text: String)

var saving := false
var dirty := false

func _ready() -> void:
	get_tree().set_auto_accept_quit(false)
	var t := Timer.new()
	t.wait_time = 30.0
	t.autostart = true
	t.timeout.connect(func(): save_now("timer"))
	add_child(t)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_now("background")
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		await save_now("quit")
		get_tree().quit()

func _local_path() -> String:
	return "user://save_%s.json" % Backend.user_id

func _write_local() -> void:
	var f := FileAccess.open(_local_path(), FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(GameState.data))

func _read_local() -> Dictionary:
	if not FileAccess.file_exists(_local_path()):
		return {}
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(_local_path()))
	return parsed if parsed is Dictionary else {}

func save_now(reason := "") -> void:
	if not Backend.logged_in() or GameState.data.is_empty():
		return
	GameState.data["saved_at"] = int(Time.get_unix_time_from_system())
	_write_local()  # local backup first, so a crash never loses progress
	if saving:
		dirty = true
		return
	saving = true
	var res := await Backend.rpc("save_game", {"p_data": GameState.data})
	saving = false
	dirty = not res.ok
	save_status.emit("Saved" if res.ok else "Offline - will retry")

func load_cloud() -> void:
	var cloud := {}
	var res := await Backend.rpc("load_game")
	if res.ok and res.data is Dictionary:
		cloud = res.data
	var local := _read_local()
	var chosen := cloud
	if int(local.get("saved_at", 0)) > int(cloud.get("saved_at", 0)):
		chosen = local   # local backup is newer (e.g. app closed while offline)
	GameState.load_data(chosen)
	GameState.check_daily()
	await save_now("login")

func logout() -> void:
	await save_now("logout")
	await Backend.sign_out()
	GameState.reset()
