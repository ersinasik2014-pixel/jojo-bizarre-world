# Setup (about 20 minutes, all from your phone browser)

## 1. Backend (Supabase, free)
1. supabase.com > Sign up > New project (any name). Save the DB password somewhere only you can see.
2. Project > Authentication > Providers > Email: keep **Confirm email ON** (this protects your OWNER account).
3. Left menu > SQL Editor > New query. Paste all of `supabase/schema.sql` > Run.
4. New query. Paste `supabase/claim_owner.sql`, replace PUT_YOUR_EMAIL_HERE with YOUR real email > Run.
5. Project Settings > API: copy **Project URL** and the **anon public** key (NOT service_role; never share that one).

## 2. Build service (GitHub, free)
1. github.com > new repository (private). Upload this project (see "Getting the files up" below).
2. Repo > Settings > Secrets and variables > Actions > New secret:
   - `SUPABASE_URL` = Project URL
   - `SUPABASE_ANON_KEY` = anon public key
3. Repo > Actions > "Build Android" > Run workflow. In ~10 min, open the run > Artifacts > android-builds > download > unzip > install the APK.

## 3. Your OWNER account
Open the game > Create Account > username **Thoxq1**, the SAME email you put in claim_owner.sql, and the password YOU choose (typed only in the game). Confirm the email, log in. You'll see the OWNER badge and Admin Panel. Nobody else can register that name.

## Getting the files up (easiest phone route)
Repo page > Code > Codespaces > Create codespace. Upload the zip (drag into file list), then in its terminal run:
`unzip jojo_bizarre_world.zip -d . && git add -A && git commit -m init && git push`
(If the zip contains a folder, move its contents to the repo root.)

## Before Google Play
Change `package/unique_name` in export_presets.cfg, create a release keystore, add secrets RELEASE_KEYSTORE_BASE64, RELEASE_KEY_ALIAS, RELEASE_KEYSTORE_PASSWORD.
