extends Node
signal changed

var username := ""
var is_owner := false   # UI hint only. The server enforces every admin action.
var data: Dictionary = {}

func default_data() -> Dictionary:
	return {
		"v": 1, "level": 1, "xp": 0, "coins": 100,
		"current_stand": "", "owned_stands": [], "stand_evolutions": {}, "stand_mastery": {},
		"unlocked_characters": ["default_hero"], "inventory": {},
		"quests": {}, "collected": [], "daily_date": "", "achievements": [],
		"position": [0.0, 1.5, 0.0],
		"settings": {"graphics": "medium", "music": 0.8, "sfx": 0.8, "ads_removed": false},
		"saved_at": 0,
	}

func load_data(d: Dictionary) -> void:
	data = default_data()
	data.merge(d, true)
	for k in ["level", "xp", "coins", "saved_at"]:
		data[k] = int(data[k])
	for k in data["inventory"].keys():
		data["inventory"][k] = int(data["inventory"][k])
	changed.emit()

func reset() -> void:
	username = ""; is_owner = false; data = {}

func enter_game() -> String:
	var p := await Backend.get_rest("/rest/v1/profiles?id=eq.%s&select=username,banned" % Backend.user_id)
	if not p.ok or not (p.data is Array) or p.data.is_empty():
		return "Could not load your profile."
	var row: Dictionary = p.data[0]
	if row.get("banned", false):
		Backend.sign_out_local()
		return "This account is banned."
	username = str(row.get("username", ""))
	var role := await Backend.rpc("get_my_role")
	is_owner = role.ok and str(role.data) == "owner"
	await SaveManager.load_cloud()
	return ""

func count(id: String) -> int:
	return int(data["inventory"].get(id, 0))

func add_item(id: String, n := 1) -> void:
	data["inventory"][id] = count(id) + n
	changed.emit()

func remove_item(id: String, n := 1) -> bool:
	if count(id) < n:
		return false
	var left := count(id) - n
	if left <= 0: data["inventory"].erase(id)
	else: data["inventory"][id] = left
	changed.emit()
	return true

func add_coins(n: int) -> void:
	data["coins"] = max(0, int(data["coins"]) + n)
	changed.emit()

func xp_needed(lvl: int) -> int:
	return 100 + lvl * 50

func add_xp(n: int) -> void:
	data["xp"] = int(data["xp"]) + n
	while int(data["xp"]) >= xp_needed(int(data["level"])):
		data["xp"] = int(data["xp"]) - xp_needed(int(data["level"]))
		data["level"] = int(data["level"]) + 1
	changed.emit()

func set_level(l: int) -> void:
	data["level"] = max(1, l); data["xp"] = 0; changed.emit()

func grant_stand(id: String, make_current := true) -> void:
	if not data["owned_stands"].has(id):
		data["owned_stands"].append(id)
	if make_current:
		data["current_stand"] = id
	changed.emit()

func check_daily() -> void:
	var today := Time.get_date_string_from_system(true)
	if data["daily_date"] != today:
		data["daily_date"] = today
		data["quests"] = {"daily_defeat_3": {"progress": 0, "done": false}}
		data["collected"] = []
