extends Control
var box: VBoxContainer
var overlay: Control

func _ready() -> void:
	UIKit.background(self)
	box = UIKit.column(self)
	_home()

func _clear() -> void:
	for c in box.get_children():
		c.queue_free()

func _home() -> void:
	_clear()
	var t := UIKit.label("JoJo: Bizarre World", 52, Color(1, 0.85, 0.3))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var who := UIKit.label("%s   Lv %d   Coins %d" % [GameState.username, GameState.data["level"], GameState.data["coins"]], 28)
	who.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(who)
	if GameState.is_owner:
		var badge := UIKit.label("★ OWNER ★", 34, Color(1, 0.8, 0.1))
		badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(badge)
	var ann := UIKit.label("", 22, Color(0.7, 0.9, 1))
	box.add_child(ann)
	_load_announcements(ann)
	box.add_child(UIKit.button("Play", func(): get_tree().change_scene_to_file("res://scenes/world.tscn")))
	box.add_child(UIKit.button("Stand Collection", _collection))
	box.add_child(UIKit.button("Settings", _settings))
	if GameState.is_owner:
		box.add_child(UIKit.button("Owner Admin Panel", _admin))
	box.add_child(UIKit.button("Logout", _logout))

func _load_announcements(lbl: Label) -> void:
	var r := await Backend.rpc("latest_announcements")
	if r.ok and r.data is Array and not r.data.is_empty():
		lbl.text = "Announcement: " + str(r.data[0]["message"])

func _logout() -> void:
	await SaveManager.logout()
	get_tree().change_scene_to_file("res://scenes/login.tscn")

func _collection() -> void:
	_clear()
	box.add_child(UIKit.button("< Back", _home))
	var owned: Array = GameState.data["owned_stands"]
	box.add_child(UIKit.label("Collected %d / %d Stands (current: %s)" % [owned.size(), Db.stands.size(), Db.stand_name(GameState.data["current_stand"])], 26))
	var part := -1
	for s in Db.stands:
		if s["part"] != part:
			part = s["part"]
			box.add_child(UIKit.label("— Part %d —" % part, 30, Color(1, 0.85, 0.3)))
		var have: bool = owned.has(s["id"])
		var line := "%s  [%s]" % [s["name"] if have else "???", s["rarity"]]
		if have and s["user"] != "": line += "  (" + s["user"] + ")"
		box.add_child(UIKit.label(line, 24, Color.WHITE if have else Color(0.5, 0.5, 0.5)))

func _settings() -> void:
	_clear()
	box.add_child(UIKit.button("< Back", func(): SaveManager.save_now("settings"); _home()))
	box.add_child(UIKit.label("Graphics quality: " + str(GameState.data["settings"]["graphics"]), 28))
	for q in ["low", "medium", "high"]:
		box.add_child(UIKit.button(q.capitalize(), func():
			GameState.data["settings"]["graphics"] = q
			_settings()))
	box.add_child(UIKit.label("Ads: rewarded ads and the ad-free purchase need the Google AdMob/Play Billing plugins (not yet integrated).", 20, Color(0.7, 0.7, 0.7)))

# ---------------- OWNER ADMIN PANEL (client UI only; server enforces ownership) ----------------
func _admin() -> void:
	if not GameState.is_owner: return
	_clear()
	box.add_child(UIKit.button("< Back", func(): SaveManager.save_now("admin"); _home()))
	box.add_child(UIKit.label("OWNER ADMIN PANEL", 36, Color(1, 0.8, 0.1)))
	var status := UIKit.label("", 22, Color(0.6, 1, 0.7))
	box.add_child(status)
	box.add_child(UIKit.button("+1,000,000 coins", func(): GameState.add_coins(1000000); status.text = "Coins: %d" % GameState.data["coins"]; SaveManager.save_now("admin")))
	box.add_child(UIKit.button("+10,000 XP", func(): GameState.add_xp(10000); status.text = "Level %d" % GameState.data["level"]; SaveManager.save_now("admin")))
	var lv := UIKit.line_edit("Set level (number)")
	box.add_child(lv)
	box.add_child(UIKit.button("Apply level", func(): if lv.text.is_valid_int(): GameState.set_level(int(lv.text)); status.text = "Level set"; SaveManager.save_now("admin")))
	box.add_child(UIKit.button("Unlock ALL Stands", func():
		for s in Db.stands: GameState.grant_stand(s["id"], false)
		status.text = "Unlocked %d Stands" % Db.stands.size(); SaveManager.save_now("admin")))
	# Stand picker
	var sq := UIKit.line_edit("Search Stand to equip")
	box.add_child(sq)
	box.add_child(UIKit.button("Equip first match", func():
		var q := sq.text.to_lower()
		for s in Db.stands:
			if str(s["name"]).to_lower().contains(q):
				GameState.grant_stand(s["id"]); status.text = "Equipped " + s["name"]; SaveManager.save_now("admin"); return
		status.text = "No match"))
	# Item spawner
	var iq := UIKit.line_edit("Search item (e.g. arrow)")
	box.add_child(iq)
	var qty := UIKit.line_edit("Quantity (default 999)")
	box.add_child(qty)
	var results := VBoxContainer.new()
	box.add_child(results)
	box.add_child(UIKit.button("Search items", func():
		for c in results.get_children(): c.queue_free()
		for it in Db.search_items(iq.text):
			results.add_child(UIKit.button("Give: " + it["name"], func():
				var n := int(qty.text) if qty.text.is_valid_int() else 999
				GameState.add_item(it["id"], n); status.text = "Gave %d x %s" % [n, it["name"]]; SaveManager.save_now("admin")))))
	box.add_child(UIKit.button("Remove ALL of searched item", func():
		for it in Db.search_items(iq.text):
			GameState.remove_item(it["id"], GameState.count(it["id"]))
		status.text = "Removed"; SaveManager.save_now("admin")))
	# Player management (server-enforced)
	var un := UIKit.line_edit("Player username")
	box.add_child(un)
	box.add_child(UIKit.button("Ban", func(): var r := await Backend.rpc("admin_set_banned", {"p_username": un.text, "p_banned": true}); status.text = "Banned" if r.ok else r.error))
	box.add_child(UIKit.button("Unban", func(): var r := await Backend.rpc("admin_set_banned", {"p_username": un.text, "p_banned": false}); status.text = "Unbanned" if r.ok else r.error))
	box.add_child(UIKit.button("View profile", func(): var r := await Backend.rpc("admin_get_player", {"p_username": un.text}); status.text = JSON.stringify(r.data).left(600) if r.ok else r.error))
	box.add_child(UIKit.button("Reset player progress", func(): var r := await Backend.rpc("admin_reset_player", {"p_username": un.text}); status.text = "Reset" if r.ok else r.error))
	var an := UIKit.line_edit("Global announcement")
	box.add_child(an)
	box.add_child(UIKit.button("Send announcement", func(): var r := await Backend.rpc("admin_announce", {"p_message": an.text}); status.text = "Sent" if r.ok else r.error))
