extends Control
var mode := "login"
var box: VBoxContainer
var email_e: LineEdit
var user_e: LineEdit
var pass_e: LineEdit
var conf_e: LineEdit
var msg: Label
var busy := false

func _ready() -> void:
	UIKit.background(self)
	box = UIKit.column(self)
	_build()

func _build() -> void:
	for c in box.get_children():
		c.queue_free()
	var t := UIKit.label("JoJo: Bizarre World", 52, Color(1, 0.85, 0.3))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var heading := {"login": "Login", "register": "Create Account", "forgot": "Forgot Password"}[mode]
	box.add_child(UIKit.label(heading, 34))
	email_e = UIKit.line_edit("Email")
	box.add_child(email_e)
	if mode == "register":
		user_e = UIKit.line_edit("Username (3-20 letters, numbers, _)")
		box.add_child(user_e)
	if mode != "forgot":
		pass_e = UIKit.line_edit("Password (8+ characters)", true)
		box.add_child(pass_e)
	if mode == "register":
		conf_e = UIKit.line_edit("Confirm Password", true)
		box.add_child(conf_e)
	msg = UIKit.label("", 24, Color(1, 0.6, 0.6))
	box.add_child(msg)
	match mode:
		"login":
			box.add_child(UIKit.button("Login", _submit))
			box.add_child(UIKit.button("Create Account", func(): _set_mode("register")))
			box.add_child(UIKit.button("Forgot Password", func(): _set_mode("forgot")))
		"register":
			box.add_child(UIKit.button("Create Account", _submit))
			box.add_child(UIKit.button("Back to Login", func(): _set_mode("login")))
		"forgot":
			box.add_child(UIKit.button("Send Reset Email", _submit))
			box.add_child(UIKit.button("Back to Login", func(): _set_mode("login")))

func _set_mode(m: String) -> void:
	mode = m
	_build()

func _say(text: String, good := false) -> void:
	msg.text = text
	msg.add_theme_color_override("font_color", Color(0.6, 1, 0.7) if good else Color(1, 0.6, 0.6))

func _submit() -> void:
	if busy: return
	var mail := email_e.text.strip_edges()
	if not mail.contains("@") or not mail.contains("."):
		_say("Enter a valid email."); return
	busy = true
	_say("Working...", true)
	match mode:
		"forgot":
			var r := await Backend.recover(mail)
			_say("If that email exists, a reset link was sent." if r.ok else r.error, r.ok)
		"register":
			var uname := user_e.text.strip_edges()
			var rx := RegEx.create_from_string("^[A-Za-z0-9_]{3,20}$")
			if rx.search(uname) == null: _say("Username must be 3-20 letters, numbers or _."); busy = false; return
			if pass_e.text.length() < 8: _say("Password must be 8+ characters."); busy = false; return
			if pass_e.text != conf_e.text: _say("Passwords do not match."); busy = false; return
			var r := await Backend.sign_up(mail, pass_e.text, uname)
			if not r.ok:
				_say(r.error)
			elif Backend.logged_in():
				await _enter()
			else:
				_say("Account created. Check your email to confirm it, then log in.", true)
				mode = "login"
		"login":
			var r := await Backend.sign_in(mail, pass_e.text)
			if r.ok: await _enter()
			else: _say("Login failed: " + r.error)
	busy = false

func _enter() -> void:
	var err := await GameState.enter_game()
	if err != "":
		_say(err)
		return
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
